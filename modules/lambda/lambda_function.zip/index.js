exports.handler = async (event) => {
  console.log('Event received:', JSON.stringify(event));
        
  const response = {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: 'Hello from Lambda in VPC Lattice demo!',
      timestamp: new Date().toISOString()
    })
  };
        
  return response;
};
